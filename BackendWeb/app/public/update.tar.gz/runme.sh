#!/bin/sh

file=/tmp/$$

help()
{
	echo "sample: ./upgrade.sh jack@192.168.4.73:/home/jack/share/upload/* rootfs"
	echo "arg 1: the files to upgrade,a Remote server address"
	echo "arg 2: 4 parts to upgrade, include uboot kernel rootfs dtb all"
}

upgrade_uboot()
{
	/usr/sbin/flash_erase /dev/mtd0 0 0 >/dev/null 2>&1
	/usr/sbin/nandwrite -p /dev/mtd0 MLO >/dev/null 2>&1

	/usr/sbin/flash_erase /dev/mtd4 0 0 >/dev/null 2>&1
	/usr/sbin/nandwrite -p /dev/mtd4 u-boot.img >/dev/null 2>&1
}
upgrade_kernel()
{
	/usr/sbin/flash_erase /dev/mtd6 0 0 >/dev/null 2>&1
	/usr/sbin/nandwrite -p /dev/mtd6 uImage >/dev/null 2>&1
}
upgrade_dtb()
{
	/usr/sbin/flash_erase /dev/mtd3 0 0 >/dev/null 2>&1
	/usr/sbin/nandwrite -p /dev/mtd3 bwcon.dtb >/dev/null 2>&1
}
upgrade_rootfs()
{
	str_old=`/usr/sbin/fw_printenv nandroot`
	num=7
	if [ "$str_old" = "nandroot=ubi0:rootfs rw ubi.mtd=7,2048" ]; then
		str_new="ubi0:rootfs rw ubi.mtd=8,2048"
		num=8
	else
		str_new="ubi0:rootfs rw ubi.mtd=7,2048"
		num=7
	fi
	/usr/sbin/flash_erase /dev/mtd$num 0 0 >/dev/null 2>&1
	/usr/sbin/ubiformat /dev/mtd$num -f rootfs.img -s 512 -O 2048 >/dev/null 2>&1
	/usr/sbin/fw_setenv nandroot $str_new >/dev/null 2>&1
}

#if [ $# -lt 2 ]; then
#	help
#	exit 0
#fi

#files=$1
#target=$2

# close miner app
systemctl stop cgminer && systemctl stop bwminer

# download files and tools
#cd /tmp/firmware
#md5sum -c md5.txt
#if [ $? -ne 0 ]; then
#	echo "error: md5sum failed"
#	exit -1
#fi

if [ -e MLO ] && [ -e u-boot.img ]; then
	upgrade_uboot
fi

if [ -e bwcon.dtb ]; then
	upgrade_dtb
fi 

if [ -e uImage ]; then
	upgrade_kernel
fi

if [ -e rootfs.img ]; then
	upgrade_rootfs
fi
